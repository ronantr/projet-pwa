import firebase from "firebase/app";
import 'firebase/auth';
import { initializeApp } from "firebase/app";

const firebaseConfig = {
    apiKey: "AIzaSyDvjnOAeeJFoz2_94wZOcI8XuleWV51o6M",
    authDomain: "chromatic-theme-338922.firebaseapp.com",
    projectId: "chromatic-theme-338922",
    storageBucket: "chromatic-theme-338922.appspot.com",
    messagingSenderId: "60759696816",
    appId: "1:60759696816:web:0720086f38c9a184d8e275"
  };
  

// Initialize Firebase 
const app = initializeApp(firebaseConfig);
firebase.initializeApp(firebaseConfig);

export const auth = firebase.auth();